import React from 'react'

function Footer() {
  return (
    <div className='flex flex-row justify-center items-center bg-slate-800 text-red-600'>
      <p className='p-6'>All right reserve by PartMaster Companay</p>
    </div>
  )
}

export default Footer
